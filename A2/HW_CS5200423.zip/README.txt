Entry Numbers and Name and Contribution:
	2020CS50440 - Sahil Shahare          	- 33.33%
	2020CS50423 - Dharmeswar Basumatary  	- 33.33%
	2020EE30313 - Vibhor Sengar		- 33.33%
	


Directory Structure:
	
HW_CS5200423
    |-> part1
    
	|->  167.txt_graph
	|->  all_graph_convert.py
	|->  main.py
	|->  fsg  #binary file
	|->  gaston #binary file
	|->  gSpan-64 #binary file
	|->  plot.py
	|->  q1.sh
	
    |-> part2
    
    	  |->generateDataset_d_dim_hpc_compiled
    	  |-> q2.py
    	  |-> elbow_plot.sh
    	  
    |-> CS5200423.pdf
    |-> README.txt
    


Files Explanation:
part1: 
	all_graph_convert.py , main.py:
		used to convert the input graph according to the input requirement of the the algorithms. 
	fsg , gSpan-64, gaston :
		binary executables
		Note that:
		 gaston  binary was recompiled by us using the source code provided so that it works fine with hpc. the compiled version provided in the link had some version incompatibility issues.
	plot.py:
		used to extract time from the output files and plot the graph.
	q1.sh:
		script file to preprocess the data and execute the commands to generate the plot. it also removes all the inter-mediatary files after the final plot is done.
	
	

part2:
	generateDataset_d_dim_hpc_compiled:
		used to generate datasets as given in the problem statement of Assignment 2
		
	q2.py
		The python file containing the code to run K-means algorithm on dataset passed as 
		command-line argument and plot the elbow-plot. Uses sklearn.cluster library for
		k-means algorithm.
	
	elbow_plot.sh
		The script file used to run the python code. The command to run is given below.
		
		
		
Execution Instructions:
	In the directory HW_CS5200423:
	
		part1:
			1) change the directory to part1 folder using command
				cd part1
				
			2) In the part1 directory, run the script file: 
				sh q1.sh
			3) After running the script q1.sh a file CS5200423.png file will be generated.
				CS5200423.png file contains the plot
			
			  
	
		part2:
			change the directory to part2 folder using command'
			
				cd part2

			execute the following command to run the code for part2
			
				sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png
				
    
   

 
