import matplotlib.pyplot as plt
gspan_list=[]
fsg_list=[]
gaston_list=[]
support_list = ["05","10","25","50","95"]
for k in range(5):
    input_file = open("gspan_output_"+support_list[k]+".txt",'r')
    lines = input_file.readlines()
    line = lines[3]
    line =line.strip()
    line = line.split('.')
    line[0]=line[0]+'.'
    decimal =""
    for i in range(len(line[1])):
        if(line[1][i].isdigit()):
            decimal = decimal+line[1][i]
    gspan_list.append(float(line[0]+decimal))
    input_file.close()
for k in range(5):
    input_file = open("fsg_output_"+support_list[k]+".txt",'r')
    lines = input_file.readlines()
    
    line = lines[len(lines)-2]
    line =line.strip()
    line = line.split(':')
    line = line[1].split('.')
    line[0] =line[0].strip()
    decimal =""
    for i in range(len(line[1])):
        if(line[1][i].isdigit()):
            decimal = decimal+line[1][i]
    fsg_list.append(float(line[0]+'.'+decimal))
    input_file.close()


for k in range(5):
    input_file = open("gaston_output_"+support_list[k]+".txt",'r')
    lines = input_file.readlines()
    line = lines[len(lines)-1]
    line =line.strip()
    line = line.split(':')
    line = line[1].split('.')
    line[0] =line[0].strip()
    decimal =""
    for i in range(len(line[1])):
        if(line[1][i].isdigit()):
            decimal = decimal+line[1][i]
    gaston_list.append(float(line[0]+'.'+decimal))
    input_file.close()
sprt_list = [5,10,25,50,95]
plt.title("Execution Time V/S Min support")
plt.xlabel("Min Support --->")
plt.ylabel("Time (in sec) --->")
plt.plot(sprt_list,gspan_list,label="gspan",marker=".")
plt.plot(sprt_list,gaston_list,label="gaston",marker=".")
plt.plot(sprt_list,fsg_list,label="fsg",marker=".")
plt.legend()
plt.grid(True)
plt.savefig("CS5200423.png")