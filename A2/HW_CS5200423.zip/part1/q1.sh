#!/bin/sh

python3 main.py $1

./fsg fsg_graph.g -s 95 > fsg_output_95.txt
./fsg fsg_graph.g -s 50 > fsg_output_50.txt
./fsg fsg_graph.g -s 25 > fsg_output_25.txt
./fsg fsg_graph.g -s 10 > fsg_output_10.txt
./fsg fsg_graph.g -s 5  > fsg_output_05.txt


./gSpan-64 -f gspan.txt -s .95 > gspan_output_95.txt
./gSpan-64 -f gspan.txt -s .50 > gspan_output_50.txt
./gSpan-64 -f gspan.txt -s .25 > gspan_output_25.txt
./gSpan-64 -f gspan.txt -s .10 > gspan_output_10.txt
./gSpan-64 -f gspan.txt -s .05 > gspan_output_05.txt


./gaston 60904 gaston.txt > gaston_output_95.txt
./gaston 32055 gaston.txt > gaston_output_50.txt
./gaston 16027 gaston.txt > gaston_output_25.txt
./gaston 6411 gaston.txt > gaston_output_10.txt
./gaston 3205 gaston.txt > gaston_output_05.txt


python3 plot.py

sleep 5
rm *.g *.fp *.txt




