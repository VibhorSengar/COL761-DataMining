from all_graph_convert import gspan,fsg,gaston
import sys

Graph_count1 = gspan(sys.argv[1])
print("Converted input graph to 'gspan.txt' ")
Graph_count2 = fsg(sys.argv[1])
print("Converted input graph to 'fsg_graph.g' ")
Graph_count3 = gaston(sys.argv[1])
print("Converted input graph to 'gaston.txt' ")







