import time
from all_graph_convert import gspan,fsg,gaston
Graph_count1 = gspan()
print("Converted input graph to 'gspan.txt' ")
Graph_count2 = fsg()
print("Converted input graph to 'fsg_graph.g' ")
Graph_count3 = gaston()
print("Converted input graph to 'gaston.txt' ")







