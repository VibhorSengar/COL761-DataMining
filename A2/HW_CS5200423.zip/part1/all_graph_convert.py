def gspan(filename):
	input_file = open(filename,'r')
	all_lines = input_file.readlines()
	input_file.close()
	count =0
	output_file =open("gspan.txt",'w')
	labels = dict()   #Created an empty dctionary
	label_count=0     #starting label
	for i  in range(0,len(all_lines)):
		row = all_lines[i]		
		if(row[0]=='#'):  #Graph  identifier
			count=count+1
			output_file.write("t # "+str(count)+'\n')
			row = all_lines[i+1]
			Nodes = int(row.strip()) #No of vertices in the graph
			for j in range(0,Nodes):  #Listina all the graphs according to requirement
				row = all_lines[i+j+2] 
				row = row.strip()
				if(labels.get(row) is None):
					labels[row] = label_count
					label_count +=1
				output_file.write("v "+str(j)+" "+str(labels[row])+'\n')
			row = all_lines[i+Nodes+2]
			Edges=int(row.strip())
			for j in range(0,Edges):
				row = all_lines[i+Nodes+j+3]
				row = row.strip()
				output_file.write("e "+row+'\n')
		i= i+3+Edges+Nodes

	output_file.close()
	return count

def fsg(filename):
	input_file = open(filename,'r')
	all_lines = input_file.readlines()
	input_file.close()
	count =0
	output_file =open("fsg_graph.g",'w')
	labels = dict()
	label_count=1
	for i  in range(0,len(all_lines)):
		row = all_lines[i]
		if(row[0]=='#'):
			count=count+1
			output_file.write("t # "+str(count)+'\n')
			row = all_lines[i+1]
			Nodes = int(row.strip())
			for j in range(0,Nodes):
				row = all_lines[i+j+2]
				row = row.strip()
				if(labels.get(row) is None):
					labels[row] = label_count
					label_count +=1
				output_file.write("v "+str(j)+" "+str(labels[row])+'\n')
			row = all_lines[i+Nodes+2]
			Edges=int(row.strip())
			for j in range(0,Edges):
				row = all_lines[i+Nodes+j+3]
				row = row.strip()
				output_file.write("e "+row+'\n')
		i= i+3+Edges+Nodes

	output_file.close()
	return count
def gaston(filename):
	input_file = open(filename,'r')
	all_lines = input_file.readlines()
	input_file.close()
	count =0
	output_file =open("gaston.txt",'w')
	labels = dict()
	label_count=0
	for i  in range(0,len(all_lines)):
		row = all_lines[i]
		if(row[0]=='#'):
			count=count+1
			output_file.write("t # "+str(count)+'\n')
			row = all_lines[i+1]
			Nodes = int(row.strip())
			for j in range(0,Nodes):
				row = all_lines[i+j+2]
				row = row.strip()
				if(labels.get(row) is None):
					labels[row] = label_count
					label_count +=1
				output_file.write("v "+str(j)+' '+str(labels[row])+'\n')
			row = all_lines[i+Nodes+2]
			Edges=int(row.strip())
			for j in range(0,Edges):
				row = all_lines[i+Nodes+j+3]
				row = row.strip()
				output_file.write("e "+row+'\n')
		i= i+3+Edges+Nodes

	output_file.close()
	count_file = open("No_of_graphs.txt",'w')
	count_file.write(str(count))
	count_file.close()
	return count
        
        
        
